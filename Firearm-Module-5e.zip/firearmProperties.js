// Adds new Weapon types of Hand Cannon and Magnum
Hooks.once("init", () => {
    CONFIG.DND5E.weaponIds.handCannon = "uuid";
    CONFIG.DND5E.weaponIds.rifle = "uuid";
    // etc etc
  });